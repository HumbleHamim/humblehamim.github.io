/* ============================================================
   PROJECTS — the single source of truth
   ------------------------------------------------------------

   Every project lives in this array. The homepage reads it to
   render the gallery; project.js reads it to render the case
   study on /project.html?slug=<slug>. No database is required.

   The shape here is deliberately close to what a database table
   would look like, so this can be swapped for Supabase later
   without rewriting the UI:

     id          unique string (used in the URL)
     title       short display name
     tag         category label (Data Viz, AI, Creative Coding, …)
     status      'planned' | 'in-progress' | 'completed'
     year        string or '' if unknown
     thumbnail   image URL or '' to show a placeholder tile
     summary     one-line description for the card
     links       { live, source, github }  — '' if not applicable
     caseStudy   optional object, only for completed projects:
                   purpose, process, tech[], challenges,
                   results, screenshots[]  — each '' if missing

   Add a project: copy one object, paste it in the array, edit.
   Remove a project: delete its object. That's it.

   IMPORTANT: do not invent content. Leave a field as '' rather
   than guessing. The UI shows a clean placeholder when a field
   is empty.
   ============================================================ */

/** @typedef {'planned'|'in-progress'|'completed'} ProjectStatus */

/**
 * @typedef {Object} Project
 * @property {string} id
 * @property {string} title
 * @property {string} tag
 * @property {ProjectStatus} status
 * @property {string} year
 * @property {string} thumbnail
 * @property {string} summary
 * @property {{ live: string, source: string, github: string }} links
 * @property {{ purpose: string, process: string, tech: string[], challenges: string, results: string, screenshots: string[] }} [caseStudy]
 */

/** @type {Project[]} */
export const projects = [
  // ----------------------------------------------------------
  // PLANNED — ideas on the wishlist, no detail page
  // ----------------------------------------------------------
  {
    id: 'placeholder-idea',
    title: 'A project idea',
    tag: 'Idea',
    status: 'planned',
    year: '',
    thumbnail: '',
    summary: 'A short note about what this project would do. Replace with a real idea.',
    links: { live: '', source: '', github: '' },
  },

  // ----------------------------------------------------------
  // IN PROGRESS — currently being built, simple card only
  // ----------------------------------------------------------
  {
    id: 'placeholder-wip',
    title: 'Work in progress',
    tag: 'Creative Coding',
    status: 'in-progress',
    year: '2025',
    thumbnail: '',
    summary: 'One line on what you are currently building. Swap for a real project.',
    links: { live: '', source: '', github: '' },
  },

  // ----------------------------------------------------------
  // COMPLETED — has a full case study. Copy this block as a
  // template for each finished project. Any empty caseStudy
  // field renders a labeled placeholder, not fake text.
  // ----------------------------------------------------------
  {
    id: 'placeholder-completed',
    title: 'A finished project',
    tag: 'Data Viz',
    status: 'completed',
    year: '2025',
    thumbnail: '',
    summary: 'One or two sentences describing what this project is and the story behind it.',
    links: { live: '', source: '', github: '' },
    caseStudy: {
      purpose: '',
      process: '',
      tech: [],
      challenges: '',
      results: '',
      screenshots: [],
    },
  },
]

/* ---- helper: human-readable status label ---- */
export const statusLabel = (s) =>
  s === 'completed' ? 'Completed'
  : s === 'in-progress' ? 'In progress'
  : 'Planned'

/* ---- helper: ordering for display ---- */
export const statusOrder = { 'in-progress': 0, 'completed': 1, planned: 2 }

/* ---- helper: find one project by id ---- */
export const getProject = (id) => projects.find((p) => p.id === id)

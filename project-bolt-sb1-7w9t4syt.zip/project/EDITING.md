# Editing your site — humble.hamim

Everything you need is plain HTML, CSS, and JS. No database, no dashboard, no paid services. Open a file in any text editor, make a change, save — the preview updates automatically.

## Where things live

| File | What it controls |
|------|------------------|
| `projects.js` | **All projects** — titles, descriptions, status, links, case studies |
| `index.html` | Homepage: intro text, about, growth section, contact form, social links |
| `project.html` + `project.js` | The case-study page template (renders automatically from `projects.js`) |
| `style.css` | Colors, fonts, spacing, animations |
| `main.js` | Homepage interactions (particles, gallery, form) |
| `public/logo.svg`, `public/favicon.svg` | The humble.hamim logo and the browser icon |

---

## 1. Add or edit a project (the most common task)

Open `projects.js`. Every project is one object inside the `projects` array. To add one, copy an existing block, paste it inside the array, and edit the fields:

```js
{
  id: 'my-new-project',            // unique, used in the URL — lowercase, no spaces
  title: 'My New Project',
  tag: 'Data Viz',                  // short category label
  status: 'in-progress',            // 'planned' | 'in-progress' | 'completed'
  year: '2025',
  thumbnail: '',                    // image URL, or '' to show a placeholder tile
  summary: 'One line describing it.',
  links: { live: '', source: '', github: '' },   // '' if not applicable
  // caseStudy is OPTIONAL — only completed projects use it
  caseStudy: {
    purpose: '',
    process: '',
    tech: [],
    challenges: '',
    results: '',
    screenshots: [],
  },
},
```

Rules that keep things honest:
- **status drives the card badge**: `Planned`, `In progress`, `Completed`.
- **Only `completed` projects get a case study.** Add the `caseStudy` object only when the project is done. The card becomes clickable and opens `project.html?slug=<id>`.
- **Leave a field as `''` (empty)** if you don't have the info yet. The page shows a clean labeled placeholder, never fake text.
- **Remove a project**: delete its whole object from the array.

### Thumbnail images
Put an image in `public/` (e.g. `public/my-project.png`) and set `thumbnail: '/my-project.png'`. Leave it empty to show the diagonal-stripe placeholder tile.

### Connecting a GitHub project
Set `links.github: 'https://github.com/yourname/repo'`. A "Code" link appears on the card. Set `links.live` too if there's a deployed demo.

---

## 2. Edit the homepage text

Open `index.html`. Search for `[EDIT]` to find every editable spot: your email (in the contact form note), social links, the "Now / At / Focus / Interests" rows in About, and skill levels. Placeholders are wrapped in a dashed lime box so you can spot them.

### Skills, certificates, achievements
In `index.html`, the **Growth** section has three cards:
- **Skills**: edit the `<li>` rows in `#skillsList`. Set `data-level` from `0` to `100` for the bar fill. Start at `0` until you're comfortable claiming a level.
- **Certificates**: add `<li>` items inside `#certList`. The placeholder shows automatically when the list is empty.
- **Achievements**: same, inside `#achList`.

---

## 3. Edit colors and fonts

Open `style.css`, top of the file. The `:root` block holds every color and font as a named variable:

```css
--bg: #101211;        --accent: #D7FF64;     --ivory: #F1F0E8;
--font-display: 'Space Grotesk', ...;
```

Change one value and it updates everywhere it's used.

---

## 4. The logo

The humble.hamim signature mark is hand-drawn SVG, used in the nav, footer, and loader. It's defined inline in `index.html`, `project.html`, and as a standalone file at `public/logo.svg`. To tweak the strokes, edit the `<path>` `d` attributes (the script) or the diagonal line coordinates. The logo inherits its color from `currentColor`, so it's white on black by default and adapts automatically.

---

## 5. The contact form

GitHub Pages is static — there's no server to receive submissions. The form opens the visitor's email app with the message prefilled, addressed to the email you put in the `form-note` line in `index.html` (search for `Sends to:`). If you later want real server-side submission, that needs a separate service (Formspree, Netlify Forms, a Supabase edge function, etc.) — not included, to keep hosting free.

---

## 6. Deploy to GitHub Pages

1. `npm run build` produces a `dist/` folder.
2. Push to GitHub. In repo Settings → Pages, publish the `dist/` folder (via GitHub Actions, or commit `dist/` to a `gh-pages` branch).
3. The `base: './'` setting in `vite.config.js` makes links work at `https://humblehamim.github.io/<repo>/` or at the root domain.

---

## What's working vs. planned

**Working now**
- Logo rebrand across nav, footer, and loading screen
- Project gallery with status badges, filter chips, thumbnails, and links
- Click-through to a case-study page for completed projects
- Contact form with mailto fallback
- Growth section (skills / certificates / achievements) with honest empty states
- Mobile nav, particle hero, scroll reveals, reduced-motion support

**Planned / not built (kept simple on purpose)**
- No database and no admin dashboard — adding projects means editing `projects.js`. The data shape is designed to map cleanly onto a Supabase table later, so a future dashboard can reuse the same fields.
- No automatic GitHub sync — projects link to GitHub manually via `links.github`.
- No LinkedIn / certificate auto-import — those are manual links for now.
- No server-side form handling — mailto only, until you add a backend service.

If you want any of the "planned" pieces next, tell me which one and I'll add it without disrupting what's here.

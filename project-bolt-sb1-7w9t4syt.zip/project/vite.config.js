import { defineConfig } from 'vite'

// Relative base so the build works on GitHub Pages regardless of repo name.
export default defineConfig({
  base: './',
  build: {
    outDir: 'dist',
    emptyOutDir: true,
    // Two HTML entry points: the homepage and the case-study template.
    rollupOptions: {
      input: {
        main: 'index.html',
        project: 'project.html',
      },
    },
  },
})

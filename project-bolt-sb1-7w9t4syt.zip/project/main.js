import './style.css'
import { projects, statusLabel, statusOrder, getProject } from './projects.js'

/* ============================================================
   humble.hamim — homepage interactions

   Sections:
     1. Loader fade-out
     2. Particle centerpiece (canvas) — responds to mouse
     3. Scroll reveal animations (IntersectionObserver)
     4. Nav scroll state + mobile toggle
     5. Project gallery (renders from projects.js) + filter
     6. Project card glow + click-through to case study
     7. Skill bars
     8. Contact form (mailto fallback — static hosting)
   ============================================================ */

const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches

/* ------------------------------------------------------------
   1. LOADER
   ------------------------------------------------------------ */
function initLoader () {
  const loader = document.getElementById('loader')
  if (!loader) return
  const hide = () => { loader.classList.add('done'); setTimeout(() => loader.remove(), 600) }
  if (document.readyState === 'complete') { requestAnimationFrame(hide); return }
  window.addEventListener('load', () => requestAnimationFrame(hide))
  // Safety: never trap the visitor if load never fires
  setTimeout(hide, 3500)
}

/* ------------------------------------------------------------
   2. PARTICLE CENTERPIECE
   A field of connected dots that drift and react to the cursor.
   Static starfield under prefers-reduced-motion.
   ------------------------------------------------------------ */
function initParticles () {
  const canvas = document.getElementById('particles')
  if (!canvas) return
  const ctx = canvas.getContext('2d')
  const hero = document.getElementById('hero')

  const ACCENT = '215, 255, 100'
  const IVORY = '241, 240, 232'
  let w = 0, h = 0, dpr = Math.min(window.devicePixelRatio || 1, 2)
  let particles = []
  const mouse = { x: -9999, y: -9999, active: false }
  let raf = null

  function size () {
    w = hero.clientWidth; h = hero.clientHeight
    canvas.width = w * dpr; canvas.height = h * dpr
    canvas.style.width = w + 'px'; canvas.style.height = h + 'px'
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0)
  }
  function build () {
    const target = Math.min(140, Math.floor((w * h) / 11000))
    particles = []
    for (let i = 0; i < target; i++) {
      particles.push({ x: Math.random() * w, y: Math.random() * h, vx: (Math.random() - 0.5) * 0.25, vy: (Math.random() - 0.5) * 0.25, r: Math.random() * 1.6 + 0.6 })
    }
  }
  function drawStatic () {
    ctx.clearRect(0, 0, w, h)
    for (const p of particles) { ctx.beginPath(); ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2); ctx.fillStyle = `rgba(${IVORY},0.5)`; ctx.fill() }
  }
  function step () {
    ctx.clearRect(0, 0, w, h)
    for (const p of particles) {
      if (mouse.active) {
        const dx = p.x - mouse.x, dy = p.y - mouse.y, d2 = dx * dx + dy * dy, R = 150
        if (d2 < R * R) { const d = Math.sqrt(d2) || 1, f = (R - d) / R * 0.6; p.vx += (dx / d) * f; p.vy += (dy / d) * f }
      }
      p.x += p.vx; p.y += p.vy; p.vx *= 0.96; p.vy *= 0.96
      p.vx += (Math.random() - 0.5) * 0.01; p.vy += (Math.random() - 0.5) * 0.01
      if (p.x < -20) p.x = w + 20; if (p.x > w + 20) p.x = -20
      if (p.y < -20) p.y = h + 20; if (p.y > h + 20) p.y = -20
    }
    const LINK = 120
    for (let i = 0; i < particles.length; i++) {
      const a = particles[i]
      for (let j = i + 1; j < particles.length; j++) {
        const b = particles[j], dx = a.x - b.x, dy = a.y - b.y, d2 = dx * dx + dy * dy
        if (d2 < LINK * LINK) { const al = (1 - Math.sqrt(d2) / LINK) * 0.5; ctx.beginPath(); ctx.moveTo(a.x, a.y); ctx.lineTo(b.x, b.y); ctx.strokeStyle = `rgba(${IVORY},${al * 0.4})`; ctx.lineWidth = 1; ctx.stroke() }
      }
    }
    if (mouse.active) {
      for (const p of particles) {
        const dx = p.x - mouse.x, dy = p.y - mouse.y, d2 = dx * dx + dy * dy
        if (d2 < 180 * 180) { const al = (1 - Math.sqrt(d2) / 180); ctx.beginPath(); ctx.moveTo(p.x, p.y); ctx.lineTo(mouse.x, mouse.y); ctx.strokeStyle = `rgba(${ACCENT},${al * 0.7})`; ctx.lineWidth = 1; ctx.stroke() }
      }
    }
    for (const p of particles) {
      ctx.beginPath(); ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2)
      const near = mouse.active && Math.hypot(p.x - mouse.x, p.y - mouse.y) < 150
      ctx.fillStyle = near ? `rgba(${ACCENT},0.95)` : `rgba(${IVORY},0.55)`; ctx.fill()
    }
    raf = requestAnimationFrame(step)
  }
  function start () {
    size(); build()
    if (prefersReducedMotion) { drawStatic(); return }
    cancelAnimationFrame(raf); step()
  }
  hero.addEventListener('mousemove', (e) => { const r = hero.getBoundingClientRect(); mouse.x = e.clientX - r.left; mouse.y = e.clientY - r.top; mouse.active = true })
  hero.addEventListener('mouseleave', () => { mouse.active = false })
  hero.addEventListener('touchmove', (e) => { if (!e.touches[0]) return; const r = hero.getBoundingClientRect(); mouse.x = e.touches[0].clientX - r.left; mouse.y = e.touches[0].clientY - r.top; mouse.active = true }, { passive: true })
  hero.addEventListener('touchend', () => { mouse.active = false })
  let resizeT; window.addEventListener('resize', () => { clearTimeout(resizeT); resizeT = setTimeout(() => { if (!prefersReducedMotion) start() }, 200) })
  start()
}

/* ------------------------------------------------------------
   3. SCROLL REVEAL
   ------------------------------------------------------------ */
function initReveal () {
  const els = document.querySelectorAll('[data-reveal]')
  if (prefersReducedMotion || !('IntersectionObserver' in window)) { els.forEach(el => el.classList.add('is-visible')); return }
  const io = new IntersectionObserver((entries) => {
    entries.forEach(en => { if (en.isIntersecting) { en.target.classList.add('is-visible'); io.unobserve(en.target) } })
  }, { threshold: 0.12, rootMargin: '0px 0px -8% 0px' })
  els.forEach(el => io.observe(el))
}

/* ------------------------------------------------------------
   4. NAV
   ------------------------------------------------------------ */
function initNav () {
  const nav = document.getElementById('nav')
  const toggle = document.getElementById('navToggle')
  const onScroll = () => { if (window.scrollY > 24) nav.classList.add('scrolled'); else nav.classList.remove('scrolled') }
  onScroll(); window.addEventListener('scroll', onScroll, { passive: true })
  toggle.addEventListener('click', () => { const open = nav.classList.toggle('open'); toggle.classList.toggle('open', open); toggle.setAttribute('aria-expanded', String(open)) })
  nav.querySelectorAll('.nav-links a').forEach(a => a.addEventListener('click', () => { nav.classList.remove('open'); toggle.classList.remove('open'); toggle.setAttribute('aria-expanded', 'false') }))
}

/* ------------------------------------------------------------
   5 + 6. PROJECT GALLERY — render + filter + glow + click
   ------------------------------------------------------------ */
const iconExt = (label) => `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M7 17 17 7 M9 7h8v8"/></svg>`

function cardHTML (p) {
  const thumb = p.thumbnail
    ? `<div class="card-thumb"><img src="${p.thumbnail}" alt="${p.title} preview" loading="lazy" /></div>`
    : `<div class="card-thumb"><div class="card-thumb-empty">No preview</div></div>`
  const links = []
  if (p.links.live) links.push(`<a href="${p.links.live}" target="_blank" rel="noopener" aria-label="Live demo">Live ${iconExt('')}</a>`)
  if (p.links.github) links.push(`<a href="${p.links.github}" target="_blank" rel="noopener" aria-label="GitHub source">Code</a>`)
  const hasCase = p.status === 'completed' && p.caseStudy
  const tag = `${p.tag || 'Project'}`
  const year = p.year ? `<span>${p.year}</span>` : '<span></span>'
  const linksHTML = links.length ? `<span class="card-links">${links.join('')}</span>` : ''
  const foot = `<div class="card-foot">${year}<span class="badge ${p.status}">${statusLabel(p.status)}</span></div>`
  const cls = `card${hasCase ? ' is-link' : ''}${links.length || hasCase ? '' : ''}`

  const inner = `
    ${thumb}
    <div class="card-body">
      <div class="card-tag">${tag}</div>
      <h3>${p.title}</h3>
      <p>${p.summary || ''}</p>
      ${linksHTML}
      ${foot}
    </div>`
  if (hasCase) return `<article class="${cls}" data-id="${p.id}" tabindex="0" role="link" aria-label="Open case study: ${p.title}">${inner}</article>`
  return `<article class="${cls}">${inner}</article>`
}

function initGallery () {
  const gallery = document.getElementById('projectGallery')
  const empty = document.getElementById('projectEmpty')
  const filter = document.getElementById('projectFilter')
  if (!gallery) return

  const sorted = [...projects].sort((a, b) => statusOrder[a.status] - statusOrder[b.status])
  let current = 'all'

  function render () {
    const list = current === 'all' ? sorted : sorted.filter(p => p.status === current)
    gallery.innerHTML = list.map(cardHTML).join('') + (empty ? empty.outerHTML : '')
    // re-bind empty node
    const e2 = document.getElementById('projectEmpty')
    if (e2) e2.hidden = list.length > 0
    bindCards()
    revealCards()
  }

  filter.addEventListener('click', (e) => {
    const btn = e.target.closest('.chip')
    if (!btn) return
    filter.querySelectorAll('.chip').forEach(c => { c.classList.remove('is-active'); c.setAttribute('aria-selected', 'false') })
    btn.classList.add('is-active'); btn.setAttribute('aria-selected', 'true')
    current = btn.dataset.filter
    render()
  })

  function bindCards () {
    gallery.querySelectorAll('.card').forEach(card => {
      card.addEventListener('mousemove', (e) => {
        const r = card.getBoundingClientRect()
        card.style.setProperty('--mx', ((e.clientX - r.left) / r.width * 100) + '%')
        card.style.setProperty('--my', ((e.clientY - r.top) / r.height * 100) + '%')
      })
      const id = card.dataset.id
      if (id) {
        const go = () => { window.location.href = `./project.html?slug=${encodeURIComponent(id)}` }
        card.addEventListener('click', go)
        card.addEventListener('keydown', (e) => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); go() } })
      }
    })
  }

  function revealCards () {
    const els = gallery.querySelectorAll('[data-reveal]')
    if (!els.length) return
    els.forEach(el => el.classList.add('is-visible'))
  }

  render()
}

/* ------------------------------------------------------------
   7. SKILL BARS
   ------------------------------------------------------------ */
function initSkills () {
  const bars = document.querySelectorAll('#skillsList .bar i')
  if (!bars.length) return
  const io = new IntersectionObserver((entries) => {
    entries.forEach(en => {
      if (!en.isIntersecting) return
      const bar = en.target, lvl = bar.dataset.level || 0
      bar.style.width = (prefersReducedMotion ? lvl : 0) + '%'
      requestAnimationFrame(() => { bar.style.width = lvl + '%' })
      io.unobserve(bar)
    })
  }, { threshold: 0.4 })
  bars.forEach(b => { b.style.width = '0%'; io.observe(b) })
}

/* ------------------------------------------------------------
   8. CONTACT FORM — mailto fallback
   GitHub Pages is static, so we open the visitor's mail client
   with the message prefilled. No data is stored.
   ------------------------------------------------------------ */
function initContact () {
  const form = document.getElementById('contactForm')
  const status = document.getElementById('formStatus')
  if (!form) return
  // The recipient address is stored in the .form-note text for easy editing.
  const note = form.querySelector('.form-note')
  const to = (note && note.textContent.match(/[\w.+-]+@[\w.-]+\.[\w]+/)) ? note.textContent.match(/[\w.+-]+@[\w.-]+\.[\w]+/)[0] : ''
  form.addEventListener('submit', (e) => {
    e.preventDefault()
    const data = new FormData(form)
    const name = (data.get('name') || '').toString().trim()
    const email = (data.get('email') || '').toString().trim()
    const msg = (data.get('message') || '').toString().trim()
    if (!to) {
      status.hidden = false
      status.textContent = 'No recipient email is configured yet. Add your email in index.html (search for "Sends to:").'
      status.className = 'form-status err'
      return
    }
    const subject = `Message from ${name || 'a visitor'} — humble.hamim`
    const body = `${msg}\n\n— ${name}\n${email}`
    window.location.href = `mailto:${to}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`
    status.hidden = false
    status.textContent = 'Opening your email app… If nothing happened, write to me directly at ' + to
    status.className = 'form-status ok'
    form.reset()
  })
}

/* ------------------------------------------------------------
   BOOT — only run homepage-specific code on the homepage.
   ------------------------------------------------------------ */
initLoader()
initParticles()
initReveal()
initNav()
initGallery()
initSkills()
initContact()

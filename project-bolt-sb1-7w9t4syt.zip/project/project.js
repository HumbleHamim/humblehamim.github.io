import './style.css'
import { projects, statusLabel, getProject } from './projects.js'

/* ============================================================
   project.js — case-study page

   Reads ?slug=<id> from the URL, finds the matching project in
   projects.js, and renders a case study. Any empty field shows
   a labeled placeholder rather than fake content. Projects that
   are not 'completed' redirect home (only completed work gets a
   detail page).
   ============================================================ */

const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches

function esc (s) {
  return String(s || '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]))
}

function shotHTML (src, alt) {
  if (src) return `<figure class="case-shot"><img src="${esc(src)}" alt="${esc(alt)} preview" loading="lazy" /></figure>`
  return `<figure class="case-shot"><div class="case-shot-empty">No screenshot yet</div></figure>`
}

function section (title, body) {
  return `<section class="case-section" data-reveal>
    <h3>${esc(title)}</h3>
    <div>${body}</div>
  </section>`
}

function field (label, value, asList) {
  if (asList) {
    const items = (Array.isArray(value) ? value : []).filter(Boolean)
    if (!items.length) return section(label, `<p class="case-placeholder">No technologies listed yet.</p>`)
    return section(label, `<ul>${items.map(t => `<li>${esc(t)}</li>`).join('')}</ul>`)
  }
  if (!value) return section(label, `<p class="case-placeholder">Nothing written here yet — I'll add this once the project is finished.</p>`)
  return section(label, `<p>${esc(value)}</p>`)
}

function render () {
  const root = document.getElementById('caseRoot')
  if (!root) return

  const params = new URLSearchParams(window.location.search)
  const slug = params.get('slug')
  const p = slug ? getProject(slug) : null

  if (!p || p.status !== 'completed') {
    root.innerHTML = `
      <div class="case-notfound">
        <h1>Project not found</h1>
        <p>This project doesn't have a case study yet. It may be planned or in progress — only completed work gets a detail page.</p>
        <a href="./index.html#work" class="hero-cta">Back to projects <span class="arrow">→</span></a>
      </div>`
    reveal(root)
    return
  }

  const cs = p.caseStudy || {}
  const shots = (cs.screenshots || []).filter(Boolean)
  const links = []
  if (p.links.live) links.push(`<a href="${esc(p.links.live)}" target="_blank" rel="noopener">Live demo →</a>`)
  if (p.links.github) links.push(`<a href="${esc(p.links.github)}" target="_blank" rel="noopener">Source code →</a>`)

  root.innerHTML = `
    <article class="case">
      <a href="./index.html#work" class="case-back">← All projects</a>
      <div class="card-tag">${esc(p.tag || 'Project')}</div>
      <h1 class="case-title">${esc(p.title)}</h1>
      <div class="case-meta">
        ${p.year ? `<span>${esc(p.year)}</span>` : ''}
        <span class="badge ${p.status}">${esc(statusLabel(p.status))}</span>
        ${links.length ? `<span class="case-links">${links.join('')}</span>` : ''}
      </div>
      ${shots.length ? shots.map((s, i) => shotHTML(s, p.title)).join('') : shotHTML('', p.title)}

      ${p.summary ? section('Overview', `<p>${esc(p.summary)}</p>`) : ''}

      ${field('Purpose', cs.purpose)}
      ${field('Process', cs.process)}
      ${field('Technologies', cs.tech, true)}
      ${field('Challenges', cs.challenges)}
      ${field('Results', cs.results)}

      <section class="case-section">
        <a href="./index.html#work" class="case-back">← Back to all projects</a>
      </section>
    </article>`

  reveal(root)
}

function reveal (root) {
  if (prefersReducedMotion || !('IntersectionObserver' in window)) {
    root.querySelectorAll('[data-reveal]').forEach(el => el.classList.add('is-visible'))
    return
  }
  const io = new IntersectionObserver((entries) => {
    entries.forEach(en => { if (en.isIntersecting) { en.target.classList.add('is-visible'); io.unobserve(en.target) } })
  }, { threshold: 0.12 })
  root.querySelectorAll('[data-reveal]').forEach(el => io.observe(el))
}

function initNav () {
  const nav = document.getElementById('nav')
  const toggle = document.getElementById('navToggle')
  const onScroll = () => { if (window.scrollY > 24) nav.classList.add('scrolled'); else nav.classList.remove('scrolled') }
  onScroll(); window.addEventListener('scroll', onScroll, { passive: true })
  toggle.addEventListener('click', () => { const open = nav.classList.toggle('open'); toggle.classList.toggle('open', open); toggle.setAttribute('aria-expanded', String(open)) })
}

render()
initNav()
